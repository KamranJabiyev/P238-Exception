﻿// See https://aka.ms/new-console-template for more information
using ConsoleApp1.Models;
using ConsoleApp1.Utilities;
using ConsoleApp1.Utilities.Exceptions;

Console.WriteLine("Hello, World!");

#region Extension
//string word = "Hello P238";
//int last_index= word.GetLastIndex();
//int count = word.GetCharCount('l');
//Console.WriteLine(count);
//Console.WriteLine(last_index);
//int findPower = 10;
//int result = findPower.GetPower(3);
//Console.WriteLine(result);
#endregion

#region Indexer
//string word = "sfdaaFDS";
//Console.WriteLine(word[3]);
//Group P238 = new Group(16);
//Student st1 = new() { Name = "Eldar", Surname = "Ehmedov" };
//Student st2 = new() { Name = "Elxan", Surname = "Memmedli" };
//Student st3 = new() { Name = "Amin", Surname = "Memmedov" };
//P238[0]=st1;
//P238[2]=st2;
//P238[3]=st3;
//P238.SetStudent(st2);
//P238.SetStudent(st3);
//Console.WriteLine(P238[0].Name+" "+ P238[0].Surname);
//Console.WriteLine(P238.GetStudent(1).Name);
//Console.WriteLine(P238.GetStudent(2).Name);
#endregion

#region Nullable
//bool? id = null;
#endregion

#region Enum
//var errorNumber = 401;
//switch (errorNumber)
//{
//    case (int)Errors.UnAuthorize:
//        Console.WriteLine("Please login correctly");
//        break;
//    case (int)Errors.NotFound:
//        Console.WriteLine("This page is not exist");
//        break;
//}
#endregion

#region Exception - Error
//int a = 5;
//try
//{
//    int divide = int.Parse(Console.ReadLine());
//    Console.WriteLine(5 / divide);
//}
//catch (DivideByZeroException ex)
//{
//    Console.WriteLine("sifira bolmek olmaz");
//}
//catch (Exception ex)
//{
//    Console.WriteLine("Error bash verdi");
//}
//finally
//{
//    Console.WriteLine("Finally");
//}

const string username= "user1";
const string password= "123456";
string inputUsername=Console.ReadLine();
string inputPassword=Console.ReadLine();
if(inputUsername==username && inputPassword == password)
{
    Console.WriteLine("Welcome!");
}
else
{
    throw new LoginException("Username or password incorrect!!!");
}
#endregion

