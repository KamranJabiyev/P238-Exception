﻿namespace ConsoleApp1.Utilities.Exceptions;

public  class LoginException:Exception
{
    public LoginException(string message):base(message)
    {
        
    }
}
