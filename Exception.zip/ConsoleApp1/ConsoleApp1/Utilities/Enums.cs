﻿namespace ConsoleApp1.Utilities;

public enum Errors { NotFound = 404, UnAuthorize = 401, NotAllowed = 405 };
