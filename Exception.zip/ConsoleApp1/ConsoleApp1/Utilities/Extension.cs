﻿namespace ConsoleApp1.Utilities;

public static class Extension
{
    public static int GetLastIndex(this string str)
    {
        return str.Length - 1;
    }

    public static int GetCharCount(this string str,char simbol)
    {
        int count = 0;
        foreach (char c in str)
        {
            if (c == simbol)
            {
                count++;
            }
        }
        return count;
    }

    public static int GetPower(this int number, int power)
    {
        int result = 1;
        for (int i = 0;  i < power; i++) 
        {
            result = number * result;
        }
        return result;
    }
}


