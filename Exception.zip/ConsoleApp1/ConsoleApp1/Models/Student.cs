﻿namespace ConsoleApp1.Models;

public class Student
{
    public string Name { get; set; }
    public string Surname { get; set; }
}
