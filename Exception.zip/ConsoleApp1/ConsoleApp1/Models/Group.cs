﻿namespace ConsoleApp1.Models;

public class Group
{
    public string Name { get; set; }
    private Student[] students;
    public Student this[int index]
    {
        get 
        { 
            return students[index]; 
        }
        set 
        {
            students[index] = value;
        }
    }
    private int _count;
    public Group(int studentCount)
    {
        _count = 0;
        students = new Student[studentCount];
    }

    //public void SetStudent(Student student)
    //{
    //    students[_count] = student;
    //    _count++;
    //}

    //public Student GetStudent(int index)
    //{
    //    return students[index];
    //}
}
